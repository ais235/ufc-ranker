# UFC Rankings Demo Page

## 📁 Contents
- `weight_class_rankings_demo.html` - Main rankings page
- `photos/` - Folder with fighter photos
- `ИНСТРУКЦИЯ.txt` - Russian instructions
- `README.md` - This file

## 🚀 How to Open

1. **Double-click** on `weight_class_rankings_demo.html`
2. **Or drag** the file into your browser window
3. **Or right-click** → "Open with" → select your browser

## 📱 Supported Browsers
- Google Chrome (recommended)
- Mozilla Firefox
- Microsoft Edge
- Safari
- Opera

## 🎯 What You'll See
- Modern UFC rankings page with black & gold styling
- Flyweight champion Alexandre Pantoja with full fighter card
- Top 15 fighters in compact cards
- Real UFC fighter photos
- Responsive design for all devices

## ⚡ Features
- All photos load locally (no internet required)
- Hover effects on fighter cards
- Color-coded win/loss/draw indicators
- Complete fighter information

## 🔧 Troubleshooting
- Make sure `photos/` folder is next to the HTML file
- Try a different browser
- Check that files aren't corrupted

## 📞 Support
Contact the developer if you encounter any issues.

---
Created: $(date)
Version: 1.0
